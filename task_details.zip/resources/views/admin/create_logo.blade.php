@include('admin.header.header')
@include('admin.menu.menu')

<div class="breadcomb-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="breadcomb-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="breadcomb-wp">
									<div class="breadcomb-icon">
										<i class="notika-icon notika-windows"></i>
									</div>
									<div class="breadcomb-ctn">
										<h2>Create Employee </h2>
										<p>Welcome to Task Details <span class="bread-ntd">Admin</span></p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
								<div class="breadcomb-report">
                                <a href="emp"><button class="btn btn-default btn-icon-notika waves-effect"><i class="fa fa-list"></i> List Employee </button></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<form action="{{ route('admin/store') }}" method="post" enctype="multipart/form-data">
@csrf
<div class="form-example-area">
<div class="container">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

    @if ($errors->any())
        <div class="alert alert-danger"><ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
            @endif

    @if ($message = Session::get('success'))<div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button><strong>{{ $message }}</strong></div>
            @endif

     @if ($message = Session::get('error'))<div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button><strong>{{ $message }}</strong></div>
            @endif

        <div class="form-example-wrap mg-t-30">
            <div class="cmp-tb-hd cmp-int-hd">
                <h2>Employee  Form</h2>
            </div>
            <div class="form-example-int form-horizental">
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Name</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="text" name="name" value="{{old('name')}}" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Email</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="text" name="email" value="{{old('email')}}" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Mobile Number</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="text" name="mobile" value="{{old('mobile')}}" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Password</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="password" name="password" value="{{old('password')}}" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">DOB</label>
                        </div>
                        <div class="col-lg-3 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="date" name="dob" value="{{old('dob')}}" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-example-int form-horizental mg-t-15">
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Profile Pic</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                            <label title="Upload image file" for="inputImage" class="btn btn-success notika-btn-success img-cropper-cp">
                            <input type="file" name="image" id="inputImage" value="{{old('file')}}" class="hide"> Upload new image
                        </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="form-example-int mg-t-15">
                <div class="row">
                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                    </div>
                    <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                        <button class="btn btn-success notika-btn-success" type="submit">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
</div>
</form>
<br><br><br><br><br><br><br>
@include('admin.footer.footer')