<?php echo $__env->make('admin.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.menu.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    i.action-fa.fa.fa-pencil-square-o {
    font-size: 30px;
}
i.action-fa.fa.fa-trash-o {
    font-size: 30px;
}
</style>
    <div class="breadcomb-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="breadcomb-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="breadcomb-wp">
									<div class="breadcomb-icon">
										<i class="notika-icon notika-windows"></i>
									</div>
									<div class="breadcomb-ctn">
										<h2>Employee Details:</h2>
										<p>Welcome to Task Details <span class="bread-ntd">Admin</span></p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
								<div class="breadcomb-report">
                                <a href="create_emp"><button class="btn btn-default btn-icon-notika waves-effect"><i class="fa fa-plus"></i> Create Employee</button></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcomb area End-->
    <!-- Data Table area Start-->
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
    <?php if(session('status')): ?>
    <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button><strong><?php echo e(session('status')); ?></strong></div>
    <?php endif; ?>
    </div>
    <div class="data-table-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="data-table-list">
                        <div class="table-responsive">
                            <table id="data-table-basic" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>SN.</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile Number</th>
                                        <th>DOB</th>
                                        <th>Profile Pic</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $allDataEmp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->mobile); ?></td>
                                        <td><?php echo e($user->dob); ?></td>
                                        <td><img src="<?php echo e(asset('storage/logo/'.$user->file_path)); ?>" height="30%" width="70px;"/></td>
                                        <td> <input data-id="<?php echo e($user->id); ?>" class="toggle-class" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" <?php echo e($user->status ? 'checked' : ''); ?>></td> 
                                        <td>
                                        <a href="<?php echo e(url('/')); ?>/admin/edit/<?php echo e($user->id); ?>"><i class="action-fa fa fa-pencil-square-o"></i></a>
                                        <a href="<?php echo e(url('/')); ?>/admin/delete/<?php echo e($user->id); ?>"><i class="action-fa fa fa-trash-o" style='color: red'></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script>

$('.toggle-class').change(function() {

    var status = $(this).prop('checked') == true ? 1 : 0; 
    var id = $(this).data('id'); 

    $.ajax({
        url: '<?php echo e(route('admin/change-status')); ?>',
        type: 'GET',
        data: {id: id,status: status },
        success: function (result) {
            console.log(result.success)
        }
    });
})

</script>

<?php echo $__env->make('admin.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\task_details\resources\views/admin/logo.blade.php ENDPATH**/ ?>