<?php echo $__env->make('admin.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.menu.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="breadcomb-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="breadcomb-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="breadcomb-wp">
									<div class="breadcomb-icon">
										<i class="notika-icon notika-windows"></i>
									</div>
									<div class="breadcomb-ctn">
										<h2>Create Employee </h2>
										<p>Welcome to Task Details <span class="bread-ntd">Admin</span></p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
								<div class="breadcomb-report">
                                <a href="emp"><button class="btn btn-default btn-icon-notika waves-effect"><i class="fa fa-list"></i> List Employee </button></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<form action="/admin/update/<?php echo e($empData->id); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-example-area">
<div class="container">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
            <?php endif; ?>

    <?php if($message = Session::get('success')): ?><div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button><strong><?php echo e($message); ?></strong></div>
            <?php endif; ?>

     <?php if($message = Session::get('error')): ?><div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button><strong><?php echo e($message); ?></strong></div>
            <?php endif; ?>

        <div class="form-example-wrap mg-t-30">
            <div class="cmp-tb-hd cmp-int-hd">
                <h2>Employee  Form</h2>
            </div>
            <div class="form-example-int form-horizental">
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Name</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="text" name="name" value="<?php echo e($empData->name); ?>" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Email</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="text" name="email" value="<?php echo e($empData->email); ?>" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Mobile Number</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="text" name="mobile" value="<?php echo e($empData->mobile); ?>" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Password</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="password" name="password" value="<?php echo e($empData->password); ?>" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">DOB</label>
                        </div>
                        <div class="col-lg-3 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="date" name="dob" value="<?php echo e($empData->dob); ?>" class="form-control input-sm" >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-example-int form-horizental mg-t-15">
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Profile Pic</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                            <label title="Upload image file" for="inputImage" class="btn btn-success notika-btn-success img-cropper-cp">
                            <input type="file" name="image" id="inputImage" class="hide"> Upload new image
                        </label>
                        <img src="<?php echo e(asset('storage/logo/'.$empData->file_path)); ?>" width="90px">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="form-example-int mg-t-15">
                <div class="row">
                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                    </div>
                    <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                        <button class="btn btn-success notika-btn-success" type="submit">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
</div>
</form>
<br><br><br><br><br><br><br>
<?php echo $__env->make('admin.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\task_details\resources\views/admin/edit.blade.php ENDPATH**/ ?>