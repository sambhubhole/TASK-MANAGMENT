<?php echo $__env->make('admin.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.menu.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="breadcomb-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="breadcomb-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="breadcomb-wp">
									<div class="breadcomb-icon">
										<i class="notika-icon notika-windows"></i>
									</div>
									<div class="breadcomb-ctn">
										<h2>Create Logo</h2>
										<p>Welcome to Alldatafinder <span class="bread-ntd">Admin</span></p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
								<div class="breadcomb-report">
                                <a href="logo"><button class="btn btn-default btn-icon-notika waves-effect"><i class="fa fa-list"></i> List Logo</button></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<form action="<?php echo e(route('admin/store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-example-area">
<div class="container">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
            <?php endif; ?>

    <?php if($message = Session::get('success')): ?><div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button><strong><?php echo e($message); ?></strong></div>
            <?php endif; ?>

        <div class="form-example-wrap mg-t-30">
            <div class="cmp-tb-hd cmp-int-hd">
                <h2>Logo Form</h2>
            </div>
            <div class="form-example-int form-horizental">
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Logo Name</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                                <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control input-sm" placeholder="Logo Name">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-example-int form-horizental mg-t-15">
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                            <label class="hrzn-fm">Image</label>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                            <div class="nk-int-st">
                            <label title="Upload image file" for="inputImage" class="btn btn-success notika-btn-success img-cropper-cp">
                            <input type="file" name="file" id="inputImage" value="<?php echo e(old('file')); ?>" class="hide"> Upload new image
                        </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="form-example-int mg-t-15">
                <div class="row">
                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
                    </div>
                    <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
                        <button class="btn btn-success notika-btn-success" type="submit">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
</div>
</form>
<br><br><br><br><br><br><br>
<?php echo $__env->make('admin.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SAMBHU\custom_login\resources\views/admin/create_logo.blade.php ENDPATH**/ ?>