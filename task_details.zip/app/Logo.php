<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Logo extends Model
{

    protected $table="logos";
    protected $fillable = ["name", "email","mobile","password","dob","file_path", "created_at", "updated_at"];

    public function getAllData(){
        $AllData = Logo::all();
    return $AllData;
    }





















}

