<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Logo;
use DB;


class LogoController extends Controller
{
    public function create_logo()
    {
        return view('admin/create_logo');
    }

    public function create()
    {
        return view('admin/logo');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:logos',
            'mobile'=>'required|min:11|numeric|unique:logos',
            'password' => 'required',
            'dob' => 'required',
            'image' => 'required',
        ]);

        //$details = ['name' => $request->name, 'email' => $request->email, 'mobile' => $request->mobile,'password' => $request->password,'dob' => $request->dob];
 
        //dd($details);
        if ($files = $request->file('image')) {
            
           $destinationPath = 'storage/logo/'; // upload path
           $profileImage = date('YmdHis') . "." . $files->getClientOriginalExtension();
           $files->move($destinationPath, $profileImage);
           $details = "$profileImage";
        }
         
        $product = new Logo([
                    "name" => $request->get('name'),
                    "email" => $request->get('email'),
                    "mobile" => $request->get('mobile'),
                    "password" => $request->get('password'),
                    "dob" => $request->get('dob'),
                    "file_path" => $details
                ]);

                //dd($product);



                $product->save();


        //$product   =   Logo::where('id', $productId)->update($details);  

        //dd($product);
        //$details->save();



        // if ($request->hasFile('file')) {

        //     $request->validate([
        //         'image' => 'mimes:jpeg,bmp,png'
        //     ]);

        //     $request->file->store('logo', 'public');

        //     $product = new Logo([
        //         "name" => $request->get('name'),
        //         "email" => $request->get('email'),
        //         "mobile" => $request->get('mobile'),
        //         "password" => $request->get('password'),
        //         "dob" => $request->get('dob'),
        //         "file_path" => $request->file->hashName()
        //     ]);
        //     $product->save();
            
        // }
        return back()->with('success','Data successfully added.');
    }

    public function alldatafetch()
    {
        $objData = new Logo();
        $AllData = $objData->getAllData();
        return view('admin/logo')->with('allDataEmp',$AllData);
    }

    public function edit($id)
    {
        $empData= Logo::find($id);
        return view('admin/edit',compact('empData'));
    }

    public function update(Request $request)
    {  
    request()->validate([
        'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
   ]);
 
    $productId = $request->id;
 
    $details = ['name' => $request->name, 'email' => $request->email, 'mobile' => $request->mobile,'password' => $request->password,'dob' => $request->dob];
 
    if ($files = $request->file('image')) {
        
       //delete old file
       //File::delete('public/product/'.$request->hidden_image);
     
       //insert new file
       $destinationPath = 'storage/logo/'; // upload path
       $profileImage = date('YmdHis') . "." . $files->getClientOriginalExtension();
       $files->move($destinationPath, $profileImage);
       $details['file_path'] = "$profileImage";
    }
     
    //$product   =   Logo::updateOrCreate(['id' => $productId], $details);
    $product   =   Logo::where('id', $productId)->update($details);  
        
    return redirect('admin/emp')->with('status', 'Update successfully!');
    //return Response::json($product);
    } 

    public function destroy($id)
    {
        $empDestroy = Logo::find($id);
        $empDestroy->delete();
        return redirect('admin/emp')->with('status', 'deleted successfully!');
    }

    public function changeStatus(Request $request){

        $id = $request->id;
        $status = $request->status;

        $user = DB::table('logos')->where('id', $id)->update(['status' => $status]);

        return response()->json(['success'=>'Status changed successfully.']);
    }









}
