<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\LogoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('admin/dashboard', [AuthController::class, 'dashboard']);
Route::get('admin/login', [AuthController::class, 'index'])->name('login');
Route::post('admin/custom-login', [AuthController::class, 'customLogin'])->name('login.custom');
Route::get('admin/registration', [AuthController::class, 'registration'])->name('register-user');
Route::post('admin/custom-registration', [AuthController::class, 'customRegistration'])->name('register.custom');
Route::get('admin/signout', [AuthController::class, 'signOut'])->name('signout');

Route::get('admin/create_emp', [LogoController::class, 'create_logo'])->name('admin/create_emp');
Route::get('admin/emp', [LogoController::class, 'alldatafetch'])->name('admin/emp');
Route::post('admin/store', [LogoController::class, 'store'])->name('admin/store');

Route::get('admin/edit/{id}', [LogoController::class, 'edit'])->name('admin/edit');
Route::post('admin/update/{id}', [LogoController::class, 'update'])->name('admin/update');
Route::get('admin/delete/{id}', [LogoController::class, 'destroy'])->name('admin/delete');
Route::get('admin/change-status', [LogoController::class, 'changeStatus'])->name('admin/change-status');





























































